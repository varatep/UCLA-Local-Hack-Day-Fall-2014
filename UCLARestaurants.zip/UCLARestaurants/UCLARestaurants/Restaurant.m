//
//  Restaurant.m
//  UCLARestaurants
//
//  Created by QINGWEI on 11/7/14.
//  Copyright (c) 2014 QINGWEI LAN. All rights reserved.
//

#import "Restaurant.h"

@implementation Restaurant

@end
